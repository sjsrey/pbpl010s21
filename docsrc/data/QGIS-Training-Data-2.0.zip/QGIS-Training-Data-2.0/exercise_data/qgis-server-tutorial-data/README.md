QGIS Server Tutorial Data
-------------------------

* for QGIS Server 2 use `world.qgs`
* for QGIS Server 3 use `world3.qgs`


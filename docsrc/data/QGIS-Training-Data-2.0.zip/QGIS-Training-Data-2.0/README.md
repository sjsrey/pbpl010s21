# QGIS-Training-Data
Data for Training Manual exercises from QGIS 3.4
